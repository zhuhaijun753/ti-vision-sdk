#
#  ======== readme.txt ========
#

ping - Send a message between all cores in the system

Overview
=========================================================================
This example is used to exercise every communication path between all
processors in the system (including local delivery on the current
processor). The example is also organized in a suitable manner to develop
an application with different compute units on each processor.

Each executable will create two tasks: 1) the server task, and 2) the
application task. The server task creates a message queue and then waits
on that queue for incoming messages. When a message is received, the
server task simply sends it back to the original sender.

The application task creates its own message queue and then opens every
server message queue in the system (including the server queue on the
local processor). The task sends a message to a server and waits for the
message to be returned. This is repeated for each server in the system
(including the local server).


Build Instructions
=========================================================================

 1. Setup a development area. A typical setup might look like this. The
    Depot folder contains installed products. The work folder contains
    each of the examples (eg. hello, ping, etc.). Each example contains
    its own products.mak file which will include a parent products.mak
    file if it exists. The parent file must be created by you.

    testbench/
     |_ Depot/
     |   |_ bios_m_mm_pp_bb/
     |   |_ ipc_m_mm_pp_bb/
     |   |_ ti_c6x_m_m_p/
     |
     |_ work/
         |_ ping/
         |   |_ core0/
         |   |_ core1/
         |   |_ core2/
         |   |_ core3/
         |   |_ core4/
         |   |_ core5/
         |   |_ makefile
         |   |_ products.mak
         |   |_ readme.txt
         |
         |_ products.mak

    In the ping example, there is a top-level makefile which simply builds
    each of the lower directories. There is a directory for each processor
    named by the IPC processor name. The folder named 'shared' contains
    common files used by all executables, such as config.bld which defines
    the memory map.

 2. Unpack the ping.zip file into the work folder.

    cd work
    unzip <...>/ping.zip

 3. Setup the build environment. Edit products.mak and set the install paths
    as defined by your physical development area. Each example has its own
    products.mak file; you may also create a products.mak file in the parent
    directory which will be used by all examples.

    DEPOT = /testbench/Depot

    BIOS_INSTALL_DIR                = $(DEPOT)/bios_m_mm_pp_bb
    IPC_INSTALL_DIR                 = $(DEPOT)/ipc_m_mm_pp_bb
    XDC_INSTALL_DIR                 = $(DEPOT)/xdctools_m_mm_pp_bb
    ti.targets.elf.C64P             = $(DEPOT)/ti_c6x_m_m_p

 4. Build the example. This will build only debug versions of the executables.
    Edit the lower makefiles and uncomment the release goals to build both
    debug and release executables.

    cd ping
    make

    Look in the following folders for the generated files. All executables
    are copied to these folders for convenience; it makes it easier when
    loading them into CCS.

    install/ping/debug/
    install/ping/release/

 5. Optional. Use the install goal to copy the executables to a specific
    folder of your choice.

    cd ping
    make install EXEC_DIR=/<full pathname>/<platform>

    The executables are copied to the following folders.

    /<full pathname>/<platform>/ping/debug
    /<full pathname>/<platform>/ping/release


Build Configuration
=========================================================================

This example can be built for a subset of all available processors. For
example, you might want to build and run this example for the following
processors: CORE0 and CORE1. Use the following instructions to configure
this example for a subset of processors.

Note: you must always run the set of processors you configured and built.
In this example, you must run the CORE0 and CORE1 executables; you
cannot run just one of them. Because the IPC has been configured for
ProcSync_ALL, all processors must participate in the call to Ipc_start().

 1. Specify the processor list in the top-level makefile.

    edit ping/makefile

    Edit the list of processors in the PROCLIST variable.

    PROCLIST = core0 core1

 2. Clean and rebuild the example.

    cd ping
    make clean
    make

    Look in the following folders for the generated files.

    ping/install/ping/debug
    ping/install/ping/release


