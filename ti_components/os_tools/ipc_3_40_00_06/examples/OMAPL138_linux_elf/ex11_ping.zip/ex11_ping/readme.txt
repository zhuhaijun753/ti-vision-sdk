#
#  ======== readme.txt ========
#

ping - Send a message between all cores in the system

Overview
=========================================================================
This example is used to exercise every communication path between all
processors in the system (including local delivery on the current
processor). The example is also organized in a suitable manner to develop
an application with different compute units on each processor.

Each executable will create two tasks: 1) the server task, and 2) the
application task. The server task creates a message queue and then waits
on that queue for incoming messages. When a message is received, the
server task simply sends it back to the original sender.

The application task creates its own message queue and then opens every
server message queue in the system (including the server queue on the
local processor). The task sends a message to a server and waits for the
message to be returned. This is repeated for each server in the system
(including the local server).


IPC Build Instructions
=========================================================================

The IPC product provides a top level GNU makefile to allow users to easily
build the various component modules, tests, and sample applications for the
supported devices. GNU make version 3.81 or greater is required. The XDC
tools (provided with most SDKs and CCS distributions) includes a pre-compiled
version of GNU make 3.81 in $(XDC_INSTALL_DIR)/gmake.

1. To build the IPC BIOS-side libraries and test run:

 make -f ipc-bios.mak

2. To configure and build the IPC Linux-side user libraries and tests run:

 make -f ipc.linux.mak
 make

3. To install the Linux-side test, you can issue the followig command:

 make install prefix=$HOME/ipc_3_00

This will install the files on your local hosts filesystem in /home/<user>/
ipc_3_00 directory which could then be copies over to the target's
filesystem for execution.

If your target's filesystem is accessible from your local host, you can set
the prefix variable to point to your target's filesystem as follows:

 make install prefix=$HOME/targetFS/usr


Build Instructions
=========================================================================

 1. Setup a development area. A typical setup might look like this. The
    Depot folder contains installed products. The work folder contains
    each of the examples (eg. hello, ping, etc.). Each example contains
    its own products.mak file which will include a parent products.mak
    file if it exists. The parent file must be created by you.

    testbench/
     |_ Depot/
     |   |_ bios_m_mm_pp_bb/
     |   |_ ipc_m_mm_pp_bb/
     |   |_ ti_c6x_m_m_p/
     |   |_ xdctools_m_mm_pp_bb/
     |
     |_ work/
         |_ ping/
         |   |_ dsp/
         |   |_ host/
         |   |_ shared/
         |   |_ makefile
         |   |_ products.mak
         |   |_ readme.txt
         |
         |_ products.mak

    In the ping example, there is a top-level makefile which simply builds
    each of the lower directories. There is a directory for each processor
    named by the IPC processor name. The folder named 'shared' contains
    common files used by all executables, such as config.bld which defines
    the memory map.

 2. Unpack the ping.zip file into the work folder.

    cd work
    unzip <...>/ping.zip

 3. Setup the build environment. Edit products.mak and set the install paths
    as defined by your physical development area. Each example has its own
    products.mak file; you may also create a products.mak file in the parent
    directory which will be used by all examples.

    DEPOT = /testbench/Depot

    BIOS_INSTALL_DIR                = $(DEPOT)/bios_m_mm_pp_bb
    IPC_INSTALL_DIR                 = $(DEPOT)/ipc_m_mm_pp_bb
    XDC_INSTALL_DIR                 = $(DEPOT)/xdctools_m_mm_pp_bb
    TOOLCHAIN_LONGNAME              = arm-none-linux-gnueabi
    TOOLCHAIN_INSTALL_DIR           = $(DEPOT)/CodeSourcery/Sourcery_G++_Lite
    ti.targets.elf.C674             = $(DEPOT)/ti_c6x_m_m_p

 4. Build the example. This will build only debug versions of the executables.
    Edit the lower makefiles and uncomment the release goals to build both
    debug and release executables.

    cd ping
    make

    Look in the following folders for the generated files. All executables
    are copied to these folders for convenience; it makes it easier when
    loading them into CCS.

    install/ping/debug/
    install/ping/release/

 5. Optional. Use the install goal to copy the executables to a specific
    folder of your choice.

    cd ping
    make install EXEC_DIR=/<full pathname>/<platform>

    The executables are copied to the following folders.

    /<full pathname>/<platform>/ping/debug
    /<full pathname>/<platform>/ping/release


Build Configuration
=========================================================================

This example can be built for a subset of all available processors. For
example, you might want to build and run this example for the following
this example for a subset of processors.

Note: you must always run the set of processors you configured and built.
cannot run just one of them. Because the IPC has been configured for
ProcSync_ALL, all processors must participate in the call to Ipc_start().

 1. Specify the processor list in the top-level makefile.

    edit ping/makefile

    Edit the list of processors in the PROCLIST variable.

    PROCLIST = dsp host

 2. Clean and rebuild the example.

    cd ping
    make clean
    make

    Look in the following folders for the generated files.

    ping/install/ping/debug
    ping/install/ping/release


Run Instructions
=========================================================================

1. Edit the variable FIRMWARE in the ./slaveloader script to the name of your dsp firmware:

    FIRMWARE=<name_of_firmware>

This script is used to load and unload the dsp firmware as well as load the rpmsg socket driver.

2. Launch a serial terminal from your console (i.e. minicom).

    minicom -w -D /dev/ttyUSBx

If you have not done so you wil press enter to stop autoboot to configure the bootargs. Once this is done type "print" to see the list of bootargs and use the command editenv <NAME_OF_BOOT_ARG> to make changes. You will want to configure the proper IP address, point to the correct kernel image and filesystem you will use. Once the bootargs are configured type "saveenv" and "boot" to save the args and boot the device.

3. Now we will login to the device. The login is "root" with no password as shown below.

    omapl138-lcdk login:root
    root@omapl138-lcdk:~#

(Optional): SSH into a another shell by running ifconfig on the target to find the IP address and bring up a different terminal and run: telnet <IP_address>. This can be useful for debugging if necessary.


4. Run the following commands to execute the application.

   # /usr/bin/lad_omapl138 log

   # ./slaveloader.sh load

   # ./app_host

The first of these commands starts the NameServer daemon.

The second script allows you to load/unload the dsp firmware (to unload replace load with unload) and rpmsg socket driver.

The third command executes the host side code.

5. To debug you can the DSP side you can display the trace by:

   # cat /debug/remoteproc/remoteproct0/trace0

or to view the LAD log by:

vi /tmp/LAD/log

5. When complete you can unload the firmware and remove the rpmsg socket by:

   # ./slaveloader.sh unload


** NOTE: to restart the application, the user must power cycle the device. **
