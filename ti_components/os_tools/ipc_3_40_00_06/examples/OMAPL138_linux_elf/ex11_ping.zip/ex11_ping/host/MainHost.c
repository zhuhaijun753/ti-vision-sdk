/*
 * Copyright (c) 2012-2015 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== MainHost.c ========
 *
 */

/* Standard headers */
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

/* package header files */
#include <ti/ipc/Std.h>
#include <ti/ipc/Ipc.h>
#include <ti/ipc/transports/TransportRpmsg.h>

/* local header files */
#include "AppHost.h"
#include "SvrHost.h"

/* private functions */
static Void MainHost_appTskFxn(UArg arg0, UArg arg1);
static Void MainHost_svrTskFxn(UArg arg0, UArg arg1);
static Void MainHost_done(Void);


/*
 *  ======== main ========
 */
Int main(Int argc, Char* argv[])
{
    int             status;
    int             ret;
    pthread_t       thread1;
    pthread_t       thread2;

    printf("--> main:\n");

    /* initialize the ipc layer */
    status = Ipc_start();

    if (status < 0) {
        printf("Ipc_start failed\n");
    }

    printf("main: ipc ready\n");

    ret = pthread_create(&thread1,NULL,(void *) &MainHost_svrTskFxn, (NULL));
    if (ret != 0) {
        printf("Failed to create thread");
    }

    ret = pthread_create(&thread2, NULL,(void *) &MainHost_appTskFxn,(NULL));
    if (ret != 0) {
        printf("Failed to create thread");
    }
    ret = pthread_join(thread1,NULL);
    if (ret != 0) {
        printf("Failed to join thread");
    }

    ret = pthread_join(thread2,NULL);
    if (ret != 0) {
        printf("Failed to join thread");
    }


    status = Ipc_stop();
    if (status < 0) {
        printf("Ipc_stop failed\n");
     }

    printf("<-- main:");
    return (0);
}

/*
 *  ======== MainHost_appTskFxn ========
 */
Void MainHost_appTskFxn(UArg arg0, UArg arg1)
{
    Int status = 0;

    printf("--> MainHost_appTskFxn:\n");

    /* application setup phase */
    status = AppHost_setup();

    if (status < 0) {
        goto leave;
    }

    /* application execute phase */
    status = AppHost_run();

    if (status < 0) {
        goto leave;
    }

    /* application shutdown phase */
    status = AppHost_destroy();

    if (status < 0) {
        goto leave;
    }

leave:
    printf("<-- MainHost_appTskFxn: %d \n",
            status);

    /* ccs debug hook */
    MainHost_done();
}

/*
 *  ======== MainHost_svrTskFxn ========
 */
Void MainHost_svrTskFxn(UArg arg0, UArg arg1)
{
    Int status = 0;

    printf("--> MainHost_svrTskFxn:\n");

    /* server setup phase */
    status = SvrHost_setup();

    if (status < 0) {
        goto leave;
    }

    /* server execute phase */
    status = SvrHost_run();

    if (status < 0) {
        goto leave;
    }

    /* server shutdown phase */
    status = SvrHost_destroy();

    if (status < 0) {
        goto leave;
    }

leave:
    printf("<-- MainHost_svrTskFxn: %d \n",
            status);
}

/*
 *  ======== MainHost_done ========
 */
Void MainHost_done(Void)
{
    printf("MainHost_done:\n");
}
