#
#  ======== readme.txt ========
#

hello - Send one-way messages from writer to reader

Overview
=========================================================================
This is the "Hello World" example for IPC. It is a very simple example
to help you get started. It is a two processor example. You can build
it for any two processors on your device, but only for two at a time.

It uses the reader/writer design pattern. One processor will be the reader
and the other will be the writer. The reader creates a message queue and
waits on it for messages. The writer opens the reader's message queue
and sends messages to it. The writer allocates the message from a shared
message pool and the reader returns the message to the pool. Thus, messages
are sent in only one direction.


Build Instructions
=========================================================================

 1. Create a work folder on your file system.

    mkdir work

 2. Extract this example into your work folder.

    cd work
    unzip <...>/ex01_hello.zip

 3. Setup the build environment. Edit products.mak and set the install paths
    as defined by your physical development area. Each example has its own
    products.mak file; you may also create a products.mak file in the parent
    directory which will be used by all examples.

    edit ex01_hello/products.mak

    IPC_INSTALL_DIR  = <...>/ipc_m_mm_pp_bb
    BIOS_INSTALL_DIR = <...>/bios_m_mm_pp_bb
    XDC_INSTALL_DIR  = <...>/xdctools_m_mm_pp_bb

    The compilers ship with CCS. You can use them to build this example.

    edit ex01_hello/products.mak

    CCS = <...>/ccsv6/tools/compiler

    gnu.targets.arm.A15F           = $(CCS)/gcc_arm_none_eabi_m_m_p
    ti.targets.elf.C66             = $(CCS)/c6000_m_m_p
    ti.targets.arm.elf.M4          = $(CCS)/arm_m_m_p
    ti.targets.arp32.elf.ARP32_far = $(CCS)/arp32_m_m_p

 4. Build the example. This will build only debug versions of the executables.
    Edit the lower makefiles and uncomment the release goals to build both
    debug and release executables.

    cd ex01_hello
    make

    By default, the example builds for dsp1 and dsp2. Look in the following
    folders for the executables.

    ex01_hello/dsp1/bin/debug/hello_dsp1.xe66
    ex01_hello/dsp2/bin/debug/hello_dsp2.xe66

 5. Issue the following commands to clean your example.

    cd ex01_hello
    make clean


Build Configuration
=========================================================================
This example can be built for any two processors. However, you must ensure
that each processor is assigned the appropriate role. One processor must
be the writer and the other processor must be the reader. In addition, you
must tell each processor the name of its peer. This is how IPC will make
the correct connections between processors.

 1. Specify which two processors to build. Edit the top-level makefile and
    modify the PROCLIST macro to specify which processors to build. The
    list of available processors in defined in the ALL macro. For example,
    to build for dsp1 and eve1, make the following changes.

    edit ex01_hello/makefile

    PROCLIST = dsp1 eve1

 2. Specify the role for each processor. You need to edit the source file
    for each processor and specify its role and name its peer.

    edit ex01_hello/dsp1/HelloDsp1.c

    Int role = Role_WRITER;
    String peer = "EVE1";

    edit ex01_hello/eve1/HelloEve1.c

    Int role = Role_READER;
    String peer = "DSP1";

    Remove the error directive. This was added as a marker in case you
    forgot to specify the role or peer. Delete the following line:

    #error Must define role and peer

 3. Clean and build your example.

    cd ex01_hello
    make clean
    make
