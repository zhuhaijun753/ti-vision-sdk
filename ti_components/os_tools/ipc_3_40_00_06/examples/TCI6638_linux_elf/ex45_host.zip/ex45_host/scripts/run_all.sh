#!/bin/sh

set -x

./thing2 &

./thing1 -n
./thing1

wait
