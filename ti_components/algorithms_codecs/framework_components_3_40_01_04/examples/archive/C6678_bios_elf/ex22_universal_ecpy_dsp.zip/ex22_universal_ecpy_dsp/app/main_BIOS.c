/*
 * Copyright (c) 2013, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
/*
 *  ======== main_BIOS.c ========
 */

#include <xdc/std.h>
#include <xdc/runtime/Diags.h>

#include <ti/sysbios/BIOS.h>

#include <ti/sdo/fc/global/FCSettings.h>
#include <ti/sdo/fc/global/Settings.h>

/* Need to configure all the FC modules before their "inits" are called */
#include <ti/sdo/fc/rman/rman.h>
#include <ti/sdo/fc/dskt2/dskt2.h>
#include <ti/sdo/fc/edma3/edma3_config.h>



#include <ti/sdo/fc/ecpy/ecpy.h>

#include <xdc/runtime/IHeap.h>
extern xdc_runtime_IHeap_Handle EXT_HEAP;

/*
 *  ======== main ========
 */
/* ARGSUSED */
Void main(Int argc, Char * argv[])
{

    /* Set default mask for FC modules */
    FCSettings_init();
    Diags_setMask(FCSETTINGS_MODNAME"+467");

    /* Configure DSKT2 heaps and scratch */
    DSKT2_daram0Heap = EXT_HEAP;
    DSKT2_daram1Heap = EXT_HEAP;
    DSKT2_daram2Heap = EXT_HEAP;

    DSKT2_saram0Heap = EXT_HEAP;
    DSKT2_saram1Heap = EXT_HEAP;
    DSKT2_saram2Heap = EXT_HEAP;

    DSKT2_esdataHeap = EXT_HEAP;
    DSKT2_iprogHeap = EXT_HEAP;
    DSKT2_eprogHeap = EXT_HEAP;

    _DSKT2_heap = EXT_HEAP;

    /* Configure RMAN */

    /* Configure EDMA3 for platform */

    /* Set this to true if you would like event queues to be configured */
    ti_sdo_fc_edma3_Settings_eventQueueSetup = TRUE;

    /* Maps event queue to specific TC */
    ti_sdo_fc_edma3_Settings_queueTCMap[0] = 0;

    /* Sets priority of event queue */
    ti_sdo_fc_edma3_Settings_queuePriority[0] = 2;

    /* Homogenous multicore platforms need their internal memory addresses to
       be qualified with the core number. FC handles this if the following
       variable is set to true */
    ti_sdo_fc_useDNUM = 1;


    /* alloc and free functions need to be assigned to appropriate delegates */
    EDMA3_PARAMS.allocFxn = &DSKT2_allocPersistent;
    EDMA3_PARAMS.freeFxn = &DSKT2_freePersistent;

    /* Since only 1 scratch group is  being used (0) by the app, configure
       the number of Params, tccs, edma/qdma channels required for that */
    EDMA3_paRamScratchSizes[1] = 15;
    EDMA3_tccScratchSizes[1] = 3;
    EDMA3_edmaChanScratchSizes[1] = 3;
    EDMA3_qdmaChanScratchSizes[1] = 0;


    /* Configure ECPY */
    ECPY_CFG_PARAMS.allocFxn = &DSKT2_allocPersistent;
    ECPY_CFG_PARAMS.freeFxn = &DSKT2_freePersistent;

    BIOS_start();
}

