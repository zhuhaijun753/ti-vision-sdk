/*
 * (C) Copyright 2013, Texas Instruments Incorporated.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <xdc/std.h>
#include <xdc/runtime/System.h>

#include <string.h>

#include <ti/sysbios/family/c66/Cache.h>
#include <ti/sdo/fc/edmamgr/edmamgr.h>

#include "edmamgr_test.h"

/*******************************************************************************
 * FUNCTION PURPOSE: Test fast transfer APIs
 *******************************************************************************
   DESCRIPTION: This function allocates one edmaMgr channels, and performs a
                single 1D1D trasnfer followed by a 1D1D fast transfer with only
                changing src and dst addresses.
 ******************************************************************************/
int32_t EdmaMgr_test_1D1Dfast(int32_t core_id)
{
  EdmaMgr_Handle  edmaMgrHandles;

  void* input_ptr=&input[0];
  void* output_ptr=&output[0];
  void* output2_ptr=&output2[0];
  int  num_bytes = BUF_SIZE;
  int  i, ret_val, errors = 0;

  /**
   *   Test 3 :
   *
   *   Single Channel, 1D1D + Fast
   */
  System_printf("EdmaMgr 1D1D,fast Test \n");
  System_printf("Chan 1: 1D1D, single transfer, fast transfer\n");

  /* Prepare input data */
  memset(input_ptr, 0xAB, num_bytes);
  Cache_wbInv(input_ptr, num_bytes, Cache_Type_ALL, TRUE);

  /* Clear output data */
  memset(output_ptr, 0, num_bytes);
  Cache_wbInv(output_ptr, num_bytes, Cache_Type_ALL, TRUE);
  memset(output2_ptr, 0, num_bytes);
  Cache_wbInv(output2_ptr, num_bytes, Cache_Type_ALL, TRUE);

  /* Allocate edmaMgr channel */
  System_printf("\tAllocating edmaMgr handle...  ");
  edmaMgrHandles = EdmaMgr_alloc(1);
  app_assert( (edmaMgrHandles != NULL), core_id, "Error with EdmaMgr_alloc(1)");
  System_printf("Success!\n");

  /* Perform 1D1D transfer and wait */
  System_printf("\tCopying %d bytes...  ", num_bytes);
  EdmaMgr_copy1D1D(edmaMgrHandles, input_ptr, output_ptr, num_bytes);
  System_printf("Done.\n");
  System_printf("\tWaiting for transfer...  ");
  EdmaMgr_wait(edmaMgrHandles);
  System_printf("Complete!\n");

  /* Verify output */
  Cache_wbInv(output_ptr, num_bytes, Cache_Type_ALL, TRUE);
  for (i=0; i<num_bytes; i++)
  {
    if(output[i] != input[i])
    {
      System_printf("\tData verification failed (i=%d)!!!!!!!!! \n",i);
      errors++;
      break;
    }
  }

  if (i==num_bytes)
  {
    System_printf("\tData verification passed \n");
  }

  /* Perform 1D1D Fast transfer and wait */
  System_printf("\tCopying %d bytes fast...  ", num_bytes);
  EdmaMgr_copyFast(edmaMgrHandles, output_ptr, output2_ptr);
  System_printf("Done.\n");
  System_printf("\tWaiting for transfer...  ");
  EdmaMgr_wait(edmaMgrHandles);
  System_printf("Complete!\n");

  /* Verify output */
  Cache_wbInv(output2_ptr, num_bytes, Cache_Type_ALL, TRUE);
  for (i=0; i<num_bytes; i++)
  {
    if(output2[i] != input[i])
    {
      System_printf("\tData verification failed (i=%d)!!!!!!!!! \n",i);
      errors++;
      break;
    }
  }

  if (i==num_bytes)
  {
    System_printf("\tData verification passed \n");
  }


  /* Free edmaMgr channel */
  System_printf("\tFreeing edmaMgr handle...  ");
  ret_val = EdmaMgr_free(edmaMgrHandles);
  app_assert( (ret_val == 0), core_id, "Error in EdmaMgr_free()");
  System_printf("Success!\n");

  System_printf("\nEdmaMgr 1D1D,fast Test: %d errors\n\n", errors);

  return (errors);
}
