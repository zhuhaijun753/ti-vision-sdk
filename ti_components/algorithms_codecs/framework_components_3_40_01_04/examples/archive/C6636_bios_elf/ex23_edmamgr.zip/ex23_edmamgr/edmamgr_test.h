/*
 * (C) Copyright 2013, Texas Instruments Incorporated.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
#ifndef ti_sdo_fc_edmamgr_EdmaMgr_TEST_
#define ti_sdo_fc_edmamgr_EdmaMgr_TEST_
#include <stdint.h>


#define BUF_SIZE_X   100
#define BUF_SIZE_Y   100
#define BUF_SIZE (BUF_SIZE_X * BUF_SIZE_Y)
extern uint8_t input[BUF_SIZE];
extern uint8_t output[BUF_SIZE];
extern uint8_t output2[BUF_SIZE];


/*********************************************************************************
 * FUNCTION PURPOSE: trap exception
 *********************************************************************************
  DESCRIPTION:      This function traps exception
  Parameters :      Inputs: statement   : statement for if check
                            core_id     : core ID
                            error       : error to be printed out
********************************************************************************/
void app_assert(int32_t statement, int32_t core_id, const char *error);


/*******************************************************************************
 * FUNCTION PURPOSE: Test a simple 1D1D transfer.
 *******************************************************************************
   DESCRIPTION: This function allocates a single edmaMgr channel and performs a
                single 1D1D transfer.
 ******************************************************************************/
int32_t EdmaMgr_test_1D1D(int32_t core_id);


/*******************************************************************************
 * FUNCTION PURPOSE: Test simulataneous 2D2D transfer and 1D1D linked transfer.
 *******************************************************************************
   DESCRIPTION: This function allocates two edmaMgr channels, and
                simultaneously performs a single 2D2D transfer, and a 1D1D
                linked transfer.
 ******************************************************************************/
int32_t EdmaMgr_test_2D2D_1D1Dlinked(int32_t core_id);


/*******************************************************************************
 * FUNCTION PURPOSE: Test fast transfer APIs
 *******************************************************************************
   DESCRIPTION: This function allocates one edmaMgr channels, and performs a
                single 1D1D trasnfer followed by a 1D1D fast transfer with only
                changing src and dst addresses.
 ******************************************************************************/
int32_t EdmaMgr_test_1D1Dfast(int32_t core_id);


/*******************************************************************************
 * FUNCTION PURPOSE: Test fast linked transfer API
 *******************************************************************************
   DESCRIPTION: This function allocates one edmaMgr channels, and performs a
                single 1D1D linked trasnfer followed by a 1D1D fast linked
                transfer with only changing src and dst addresses.
 ******************************************************************************/
int32_t EdmaMgr_test_1D1Dlinkedfast(int32_t core_id);


/*******************************************************************************
 * FUNCTION PURPOSE: Test for the maximum number of channels that can be
                     allocated.
 *******************************************************************************
   DESCRIPTION: This function allocated as many edmaMgr channels which is
                possible.
 ******************************************************************************/
int32_t EdmaMgr_test_maxChannels(int32_t core_id);

#endif /* ti_sdo_fc_edmamgr_EdmaMgr_TEST_ */
