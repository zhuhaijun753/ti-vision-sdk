/*
 * Copyright (c) 2012, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */
/*
 *  ======== app.c ========
 *
 *  Create and run algorithm that use DSKT2 to allocate persistent and
 *  scratch memory.
 */


#include <xdc/std.h>
#include <stdlib.h>
#include <xdc/runtime/Diags.h>
#include <xdc/runtime/Memory.h>
#include <xdc/runtime/System.h>

#include <xdc/runtime/knl/SemThread.h>
#include <xdc/runtime/knl/Thread.h>
#include <ti/sdo/fc/dskt2/dskt2.h>

#include "../codec/usescratch_ti.h"

#define MOD_NAME "SMP_DSKT2_EXAMPLE"

#define BUFSIZE 0x40

#define NUMAUDIOTASKS        3       /* Number of tasks to create */
#define NUMVIDEOTASKS        3       /* Number of tasks to create */
#define LOOPCOUNT       10      /* # of times to run an algorithm instance */
#define NUMINSTANCES    2       /* # of alg instances to create */
#define AUDIOPRI        3
#define VIDEOPRI        6
extern Void smain(Int argc, Char * argv[]);
extern Void processData(IArg arg);

/* Gets posted by last task to finish */
static SemThread_Handle done = NULL;
/*
 *  ======== smain ========
 */
Void smain(Int argc, Char * argv[])
{
    Thread_Handle    thread;
    Thread_Params    threadParams;
    SemThread_Params semParams;
    Int              i;
    /* Protect DSKT2_createAlg and DSKT2_freeAlg */
    SemThread_Handle mutex = NULL;
    Int numTasks = 0;        /* Number of scratch tasks currently running */

    System_printf("EXAMPLE> Started.\n");
    SemThread_Params_init(&semParams);
    done = SemThread_create(0, &semParams, NULL); /* count = 0 */

    SemThread_Params_init(&semParams);
    mutex = SemThread_create(1, &semParams, NULL); /* count = 1 */
    if (done == NULL || mutex == NULL) {
        System_abort("SemThread_create() failed\n");
    }

    //Thread_sleep(1, NULL);
    //Thread_sleep(2, NULL);
    //Thread_sleep(3, NULL);
    Thread_sleep((Uns)rand() % 8, NULL);

    /* Create tasks that use scratch memory */

    /* Audio tasks will stay active for relatively shorter amount of time */
    for (i = 0; i < NUMAUDIOTASKS; i++) {
        Thread_Params_init(&threadParams);
        threadParams.osPriority = AUDIOPRI;
        threadParams.arg = (IArg)0;

        System_printf("smain> Creating audio thread %d\n", i);
        thread = Thread_create((Thread_RunFxn)processData, &threadParams, NULL);
        if (thread == NULL) {
            System_printf("Thread_create() of thread %d failed\n", i);
            System_abort("Aborting...\n");
        }
        else {
            numTasks++;
        }
    }


    /* Video tasks will stay active for longer, might idle while coprocessor
       processes images etc */
    for (i = 0; i < NUMVIDEOTASKS; i++) {
        Thread_Params_init(&threadParams);


        threadParams.osPriority = VIDEOPRI;
        threadParams.arg = (IArg)1;

        System_printf("smain> Creating video thread %d\n", i);
        thread = Thread_create((Thread_RunFxn)processData, &threadParams, NULL);
        if (thread == NULL) {
            System_printf("Thread_create() of thread %d failed\n", i);
            System_abort("Aborting...\n");
        }
        else {
            numTasks++;
        }
    }

    /* Linux threads will not run until you call Thread_start() */
    Thread_start(NULL);

    /* Wait for tasks to finish */
    System_printf("smain> Waiting for tasks to finish...\n");
    for (i = 0; i < (NUMAUDIOTASKS + NUMVIDEOTASKS); i++) {
        SemThread_pend(done, SemThread_FOREVER, NULL);
    }

    System_printf("======== EXAMPLE FINISHED ========\n");

    exit(0);
}

/* ARGSUSED */
Void processData(IArg arg)
{
    IUSESCRATCH_Handle  alg;
    IUSESCRATCH_Params  params = IUSESCRATCH_PARAMS;
    IALG_Fxns          *fxns;
    Int                 scratchId = arg;
    Int                 status = USESCRATCH_SOK;

    System_printf("processData> Entered\n");

    fxns = (IALG_Fxns *)&USESCRATCH_TI_IUSESCRATCH;
    params.value = 0xC0FFEE;           /* Value to put in scratch memory */
    params.av = arg;
    params.fxns = fxns;

    /* Create, activate, and run alg */
    alg = (IUSESCRATCH_Handle)DSKT2_createAlg(scratchId, fxns, NULL,
            (IALG_Params *)&params);

    /* Set trace for DSKT2 module */
    Diags_setMask(MOD_NAME"+4567");
    Diags_setMask(MOD_NAME"-EX123");

    if (alg == NULL) {
        status = USESCRATCH_EMEMORY;
    }
    else {
        DSKT2_activateAlg(scratchId, (IALG_Handle)alg);

        status = alg->fxns->useScratch((IALG_Handle)alg);

        DSKT2_deactivateAlg(scratchId, (IALG_Handle)alg);

        /* Free alg */
        DSKT2_freeAlg(scratchId, (IALG_Handle)alg);
    }


    /* If System is configured with SysMin, need to flush to see output */

    SemThread_post(done, NULL);

}
