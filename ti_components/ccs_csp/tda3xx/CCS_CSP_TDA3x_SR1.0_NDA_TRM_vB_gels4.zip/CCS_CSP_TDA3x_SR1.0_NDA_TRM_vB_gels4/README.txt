ABOUT:
--

This CSP is based on TDA3x Device Silicon Revision 1.0 and the TDA3x Technical Reference Manual(TRM).

--

TI Confidential � NDA Restrictions

--

History:

(CCS_CSP_TDA3x_SR1.0_NDA_TRM_vB_gels4) - July 2015

	1. Gel files updates and bug fixes.

(CCS_CSP_TDA3x_SR1.0_NDA_TRM_vB_gels3) - February 2015

	1. Vision SDK support added.
	
(CCS_CSP_TDA3x_ES1.0_NDA_TRM_vB_gels2) - November 2014

	1.	Gel files updates
	2. 	Device XML updates

(CCS_CSP_TDA3x_ES1.0_NDA_TRM_vB) - September 2014

	1.	Initial Release

