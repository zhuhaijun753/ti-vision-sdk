ABOUT:
--

This CSP is based on TDA2x Device Silicon Revision 1.0 and the TDA2x Technical Reference Manual(TRM).

--

TI Confidential � NDA Restrictions

--


History:

(CCS_CSP_ADAS_S28_ES1.0_NDA_TRM_vA_gels6)

1.	Default MMU configuration added for EVEs
2.	Added Self-branch instructions for DSPs and EVEs to allow reliable connectivity
3.	Fixed an invalid error returned during DPLL locking
4.	Fixed memory map for A15 CPU0/1 to allow access to DSS/GPU/IPU2 registers
7. 	Remove all �vayu_XXX.gel� files as not needed. 

(CCS_CSP_ADAS_S28_ES1.0_NDA_TRM_vA_gels7)
1.	EMIF configuration
	a.	Sequence fixed to avoid extra SDRAM_CONFIG write at the end
	b.	Clean-up of register write sequence for easy maintenance across DDR2/DDR3/Operating frequencies
	c.	EMIF interleaving is enabled by default
	d.	Programming model for HW leveling is included � this is disabled by default and will be supported post characterization
2.	PRCM/PLL
	a.	Added support for PLL configuration based on ADAS/DRA7x devices and OPP � This needs to selected appropriately in OnTargetConnect() in DRA7xx_startup_common.gel
		i.	ADAS + OPPNOM configuration is enabled by default.
		ii.	Other configuration are available via Scripts menu.
	b.	Added DRA7xx_PRCM_Clock_GetConfig() function � available under the menu item "DRA7xx PRCM CLOCK Configuration - Common"
	c.	Removed incorrect module enables
	d.	No difference in module enables for ADAS vs. DRA7x devices
3.	DebugSS 
	a.	PLL Configuration done at a single location now � from CS_DAP_DEBUGSS
4.	Added Media Local Bus (MLB) configuration GEL file.

(CCS_CSP_TDA2x_ES1.1_NDA_TRM_vQ_gels8)
1.	Latest gels included
2. 	Fixed bug in the installer, where the package will not install if there was not older version already installed in CCS

(CCS_CSP_TDA2x_SR1.1_NDA_TRM_vQ_gels9)
1.	VISION SDK support added.

(CCS_CSP_TDA2x_SR1.1_NDA_TRM_vQ_gels10)
1.	Gel files updates and bug fixes.
