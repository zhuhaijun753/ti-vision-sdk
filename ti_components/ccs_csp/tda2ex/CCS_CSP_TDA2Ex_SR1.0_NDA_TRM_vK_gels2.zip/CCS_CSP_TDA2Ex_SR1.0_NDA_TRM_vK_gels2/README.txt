ABOUT:
--

This CSP is based on TDA2Ex Device Silicon Revision 1.0 and the TDA2Ex Technical Reference Manual(TRM).

--

TI Confidential � NDA Restrictions

--


History:

(CCS_CSP_TDA2Ex_SR1.0_NDA_TRM_vK) - February 2015
1.	Initial release with VISION SDK support.

(CCS_CSP_TDA2Ex_SR1.0_NDA_TRM_vK_gels2) - July 2015
1.	Gel files updates and bug fixes.
